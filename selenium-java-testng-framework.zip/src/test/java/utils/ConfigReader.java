package utils;

public class ConfigReader {
    // Load config properties
}