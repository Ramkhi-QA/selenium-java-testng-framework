package tests;

public class LoginTest {
    // Test methods using TestNG
}