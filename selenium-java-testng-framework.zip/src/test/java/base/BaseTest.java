package base;

public class BaseTest {
    // WebDriver setup here
}