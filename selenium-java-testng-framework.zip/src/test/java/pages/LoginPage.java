package pages;

public class LoginPage {
    // Page Object elements here
}